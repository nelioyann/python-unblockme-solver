'''
# 1 profondeur 4 Taille 4x4
Blocs([1, 0, 1, 1])
Blocs([0, 2, 1, 2])


# 2 profondeur 5 Taille 4x4
Blocs([1, 0, 1, 1])
Blocs([0, 2, 1, 2])
Blocs([2, 1, 2, 2])


#3:profondeur 7 Taille 4x4
Blocs([1, 0, 1, 1])
Blocs([0, 2, 1, 2])
Blocs([2, 1, 2, 2])
Blocs([3, 2, 3, 3])

#4:profondeur 6 Taille 4x4
Blocs([1, 0, 1, 1])
Blocs([0, 2, 0, 3])
Blocs([1, 2, 2, 2])
Blocs([1, 3, 2, 3])
Blocs([3, 2, 3, 3])

#5:profondeur 8 Taille 4x4
Blocs([1, 0, 1, 1])
Blocs([0, 2, 1, 2])
Blocs([0, 3, 1, 3])
Blocs([2, 1, 2, 2])
Blocs([3, 1, 3, 2])

#6:profondeur 9 Taille 5x5
Blocs([1, 0, 1, 1])
Blocs([2, 0, 3, 0])
Blocs([1, 2, 2, 2])
Blocs([4, 1, 4, 2])
Blocs([2, 3, 2, 4])
Blocs([0, 4, 1, 4])


#7: profondeur 14 Taille 5x5
Blocs([1, 0, 1, 1])
Blocs([2, 0, 3, 0])
Blocs([1, 2, 2, 2])
Blocs([4, 1, 4, 2])
Blocs([2, 3, 2, 4])
Blocs([0, 4, 1, 4])
Blocs([0, 3, 1, 3])
Blocs([2, 1, 3, 1])

'''
